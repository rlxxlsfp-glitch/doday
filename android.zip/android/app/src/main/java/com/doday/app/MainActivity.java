package com.doday.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialException;

import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;

import org.json.JSONObject;

import java.util.concurrent.Executors;

public class MainActivity extends Activity {
  static final String URL = "https://rlxxlsfp-glitch.github.io/doday/";
  WebView web;

  @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    web = new WebView(this);
    web.setBackgroundColor(Color.parseColor("#FCEFF2"));
    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setDatabaseEnabled(true);
    s.setMediaPlaybackRequiresUserGesture(false);
    s.setUserAgentString(s.getUserAgentString() + " DodayApp/1");
    web.addJavascriptInterface(new Bridge(), "DodayNative");
    web.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
        Uri u = r.getUrl();
        if (u.toString().startsWith(URL) || "vocap-e3e9e.firebaseapp.com".equals(u.getHost())) return false;
        try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception e) {}
        return true;
      }
    });
    setContentView(web);
    Notif.channels(this);
    web.loadUrl(URL + pathFrom(getIntent()));
  }

  String pathFrom(Intent i) {
    String go = i == null ? null : i.getStringExtra("go");
    return go != null ? "?go=" + go : "";
  }

  @Override protected void onNewIntent(Intent i) {
    super.onNewIntent(i);
    String go = i.getStringExtra("go");
    if (go != null && web != null) web.evaluateJavascript("window.nativeGo&&nativeGo('" + go + "')", null);
  }

  @Override public void onBackPressed() {
    if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
  }

  void js(String code) { runOnUiThread(() -> web.evaluateJavascript(code, null)); }

  class Bridge {
    @JavascriptInterface public boolean notifAllowed() {
      return Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }
    @JavascriptInterface public void askNotif() {
      if (Build.VERSION.SDK_INT >= 33 && !notifAllowed()) runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7));
      else js("window.nativeNotifResult&&nativeNotifResult(" + notifAllowed() + ")");
    }
    // 저녁 알림에 쓸 정보 (일정·미룬 할 일)
    @JavascriptInterface public void setSchedule(String json, boolean on) {
      Sched.save(MainActivity.this, json, on);
    }
    // 타이머: running, elapsedMs, title
    @JavascriptInterface public void timer(boolean running, double elapsedMs, String title) {
      Notif.timer(MainActivity.this, running, (long) elapsedMs, title);
    }
    @JavascriptInterface public void timerStop() { Notif.timerStop(MainActivity.this); }
    @JavascriptInterface public void googleSignIn(String webClientId) {
      CredentialManager cm = CredentialManager.create(MainActivity.this);
      GetSignInWithGoogleOption opt = new GetSignInWithGoogleOption.Builder(webClientId).build();
      GetCredentialRequest req = new GetCredentialRequest.Builder().addCredentialOption(opt).build();
      runOnUiThread(() -> cm.getCredentialAsync(MainActivity.this, req, new CancellationSignal(), Executors.newSingleThreadExecutor(),
        new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
          @Override public void onResult(GetCredentialResponse r) {
            Credential c = r.getCredential();
            if (c instanceof CustomCredential && GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(c.getType())) {
              String tok = GoogleIdTokenCredential.createFrom(c.getData()).getIdToken();
              js("window.nativeIdToken&&nativeIdToken(" + JSONObject.quote(tok) + ")");
            } else js("window.nativeIdToken&&nativeIdToken(null,'type')");
          }
          @Override public void onError(GetCredentialException e) {
            js("window.nativeIdToken&&nativeIdToken(null," + JSONObject.quote(String.valueOf(e.getMessage())) + ")");
          }
        }));
    }
  }

  @Override public void onRequestPermissionsResult(int code, String[] p, int[] g) {
    boolean ok = g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED;
    js("window.nativeNotifResult&&nativeNotifResult(" + ok + ")");
  }
}
