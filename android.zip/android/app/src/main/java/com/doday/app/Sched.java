package com.doday.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/** 저녁 6시(일정) · 8시(미룬 할 일) 알림 예약 */
public class Sched {
  static final int SCHED_H = 18, LEFT_H = 20, LEFT_MIN = 3;

  static SharedPreferences sp(Context c) { return c.getSharedPreferences("doday", Context.MODE_PRIVATE); }

  static void save(Context c, String json, boolean on) {
    sp(c).edit().putString("snap", json).putBoolean("on", on).apply();
    if (on) planAll(c); else cancelAll(c);
  }

  static PendingIntent pi(Context c, String kind) {
    Intent i = new Intent(c, AlarmReceiver.class).putExtra("kind", kind);
    return PendingIntent.getBroadcast(c, kind.equals("sched") ? 100 : 101, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
  }

  static void planAll(Context c) { plan(c, "sched", SCHED_H); plan(c, "left", LEFT_H); }

  static void cancelAll(Context c) {
    AlarmManager am = c.getSystemService(AlarmManager.class);
    am.cancel(pi(c, "sched")); am.cancel(pi(c, "left"));
  }

  static void plan(Context c, String kind, int hour) {
    Calendar t = Calendar.getInstance();
    t.set(Calendar.HOUR_OF_DAY, hour); t.set(Calendar.MINUTE, 0); t.set(Calendar.SECOND, 0); t.set(Calendar.MILLISECOND, 0);
    if (t.getTimeInMillis() <= System.currentTimeMillis()) t.add(Calendar.DATE, 1);
    AlarmManager am = c.getSystemService(AlarmManager.class);
    boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
    if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.getTimeInMillis(), pi(c, kind));
    else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.getTimeInMillis(), pi(c, kind));
  }

  static String ymd(Calendar c) { return new SimpleDateFormat("yyyy-MM-dd", Locale.KOREA).format(c.getTime()); }

  static String jo(String w, String a, String b) {
    char ch = w.charAt(w.length() - 1); int x = ch - 0xAC00;
    return w + (x >= 0 && x <= 11171 && x % 28 != 0 ? a : b);
  }

  static final String[] TYPES = {"perf", "수행평가", "acad", "특별 일정", "exam", "시험"};
  static String typeName(String ty) { for (int i = 0; i < TYPES.length; i += 2) if (TYPES[i].equals(ty)) return TYPES[i + 1]; return "일정"; }

  /** 알림을 띄웠으면 true */
  static boolean fire(Context c, String kind) {
    if (!sp(c).getBoolean("on", false)) return false;
    try {
      JSONObject s = new JSONObject(sp(c).getString("snap", "{}"));
      Calendar now = Calendar.getInstance(); String t = ymd(now);
      Calendar tmC = Calendar.getInstance(); tmC.add(Calendar.DATE, 1); String tm = ymd(tmC);
      Random rnd = new Random();
      if (kind.equals("sched")) {
        JSONArray ev = s.optJSONArray("ev"); List<String> names = new ArrayList<>(); LinkedHashSet<String> tys = new LinkedHashSet<>();
        if (ev != null) for (int i = 0; i < ev.length(); i++) { JSONObject e = ev.getJSONObject(i); if (tm.equals(e.optString("d"))) { names.add(e.optString("t")); tys.add(e.optString("ty", "etc")); } }
        JSONObject ex = s.optJSONObject("exam"); String exT = ex == null ? "시험" : ex.optString("t", "시험");
        JSONArray days = ex == null ? new JSONArray() : ex.optJSONArray("days");
        boolean exTm = false, exToday = false;
        if (days != null) for (int i = 0; i < days.length(); i++) { if (tm.equals(days.optString(i))) exTm = true; if (t.equals(days.optString(i))) exToday = true; }
        if (names.isEmpty() && !exTm) return false;
        String title;
        if (exTm && names.isEmpty()) title = exToday ? "내일도 " + exT + " 있어요!" : "내일부터 " + jo(exT, "이에요", "예요") + "!";
        else {
          int n = names.size() + (exTm ? 1 : 0);
          String w = tys.size() == 1 && !exTm ? typeName(tys.iterator().next()) : "일정";
          title = "내일 " + jo(w, "이", "가") + (n > 1 ? " " + n + "개" : "") + " 있어요!";
        }
        if (exTm) names.add(0, exT);
        String[] tails = {"오늘 미리 챙겨 두면 마음이 편해요", "준비물이랑 할 거 지금 한 번 확인해요", "자기 전에 한 번만 더 점검해요"};
        Notif.remind(c, Notif.ID_SCHED, title, String.join(" · ", names) + "\n" + tails[rnd.nextInt(3)], null);
        return true;
      } else {
        JSONObject left = s.optJSONObject("left"); int n = 0;
        if (left != null) for (Iterator<String> it = left.keys(); it.hasNext(); ) { String d = it.next(); if (d.compareTo(t) < 0) n += left.optInt(d); }
        if (n < LEFT_MIN) return false;
        String nm = s.optString("name", ""); nm = nm.isEmpty() ? "" : nm + "님, ";
        String[][] v = {
          {"미룬 할 일이 " + n + "개나 쌓였어요!", nm + "지금 딱 하나만 시작해 봐요. 시작이 제일 어려워요"},
          {"밀린 할 일 " + n + "개, 오늘 좀 줄여 볼까요?", nm + "제일 짧은 것부터 하나 골라서 시작해요"},
          {"아직 " + n + "개가 기다리고 있어요", nm + "지금 시작하면 자기 전에 꽤 줄일 수 있어요!"}};
        String[] m = v[rnd.nextInt(3)];
        Notif.remind(c, Notif.ID_LEFT, m[0], m[1], "left");
        return true;
      }
    } catch (Exception e) { return false; }
  }
}
