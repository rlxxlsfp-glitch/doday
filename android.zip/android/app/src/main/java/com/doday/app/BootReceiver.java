package com.doday.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
  @Override public void onReceive(Context c, Intent i) {
    if (Sched.sp(c).getBoolean("on", false)) Sched.planAll(c);
  }
}
