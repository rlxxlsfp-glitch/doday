package com.doday.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
  @Override public void onReceive(Context c, Intent i) {
    String kind = i.getStringExtra("kind");
    if (kind == null) return;
    Sched.fire(c, kind);
    if (Sched.sp(c).getBoolean("on", false)) Sched.plan(c, kind, kind.equals("sched") ? Sched.SCHED_H : Sched.LEFT_H);
  }
}
