package com.doday.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.SystemClock;
import android.graphics.Typeface;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.View;
import android.widget.RemoteViews;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Notif {
  static final String CH_TIMER = "timer", CH_REMIND = "remind";
  static final int ID_TIMER = 1, ID_SCHED = 2, ID_LEFT = 3;

  static void channels(Context c) {
    NotificationManager nm = c.getSystemService(NotificationManager.class);
    NotificationChannel t = new NotificationChannel(CH_TIMER, "공부 타이머", NotificationManager.IMPORTANCE_LOW);
    t.setDescription("시간 측정 중일 때 알림 창에 타이머를 보여 줘요");
    t.setShowBadge(false);
    nm.createNotificationChannel(t);
    NotificationChannel r = new NotificationChannel(CH_REMIND, "일정 · 미룬 할 일", NotificationManager.IMPORTANCE_HIGH);
    r.setDescription("수행평가 전날, 미룬 할 일이 쌓였을 때 알려 줘요");
    nm.createNotificationChannel(r);
  }

  static PendingIntent open(Context c, String go, int req) {
    Intent i = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
    if (go != null) i.putExtra("go", go);
    return PendingIntent.getActivity(c, req, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
  }

  static RemoteViews view(Context c, int layout, boolean running, long elapsed, CharSequence title, String since) {
    RemoteViews v = new RemoteViews(c.getPackageName(), layout);
    v.setViewVisibility(R.id.pillOn, running ? View.VISIBLE : View.GONE);
    v.setViewVisibility(R.id.pillOff, running ? View.GONE : View.VISIBLE);
    v.setTextViewText(R.id.title, title);
    if (layout == R.layout.notif_timer_big) v.setTextViewText(R.id.since, since);
    v.setChronometer(R.id.chrono, SystemClock.elapsedRealtime() - elapsed, null, running);
    if (!running) v.setTextColor(R.id.chrono, Color.parseColor("#8A8690"));
    return v;
  }

  static void timer(Context c, boolean running, long elapsed, String subj, String title, long startedAt) {
    channels(c);
    String plain = (subj == null || subj.isEmpty()) ? title : subj + " · " + title;
    SpannableString big = new SpannableString(plain);
    if (subj != null && !subj.isEmpty()) {
      big.setSpan(new ForegroundColorSpan(Color.parseColor("#D4537E")), 0, subj.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }
    String since = startedAt > 0 ? new SimpleDateFormat("HH:mm", Locale.KOREA).format(new Date(startedAt)) + " 시작" : "";
    Notification n = new Notification.Builder(c, CH_TIMER)
        .setSmallIcon(R.drawable.ic_stat)
        .setColor(Color.parseColor("#D2638A"))
        .setStyle(new Notification.DecoratedCustomViewStyle())
        .setCustomContentView(view(c, R.layout.notif_timer, running, elapsed, plain, since))
        .setCustomBigContentView(view(c, R.layout.notif_timer_big, running, elapsed, big, since))
        .setContentTitle(running ? "공부 중" : "일시정지")
        .setContentText(plain)
        .setCategory(android.os.Build.VERSION.SDK_INT >= 31 ? Notification.CATEGORY_STOPWATCH : Notification.CATEGORY_PROGRESS)
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .setShowWhen(false)
        .setContentIntent(open(c, null, 1))
        .build();
    c.getSystemService(NotificationManager.class).notify(ID_TIMER, n);
  }

  static void timerStop(Context c) { c.getSystemService(NotificationManager.class).cancel(ID_TIMER); }

  static void remind(Context c, int id, String title, String body, String go) {
    channels(c);
    Notification n = new Notification.Builder(c, CH_REMIND)
        .setSmallIcon(R.drawable.ic_bell)
        .setColor(Color.parseColor("#D2638A"))
        .setContentTitle(title)
        .setContentText(body.replace("\n", " · "))
        .setStyle(new Notification.BigTextStyle().bigText(body))
        .setAutoCancel(true)
        .setContentIntent(open(c, go, 10 + id))
        .build();
    c.getSystemService(NotificationManager.class).notify(id, n);
  }
}
