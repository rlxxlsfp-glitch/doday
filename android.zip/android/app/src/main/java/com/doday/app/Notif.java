package com.doday.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.SystemClock;
import android.widget.RemoteViews;

public class Notif {
  static final String CH_TIMER = "timer", CH_REMIND = "remind";
  static final int ID_TIMER = 1, ID_SCHED = 2, ID_LEFT = 3;

  static void channels(Context c) {
    NotificationManager nm = c.getSystemService(NotificationManager.class);
    NotificationChannel t = new NotificationChannel(CH_TIMER, "공부 타이머", NotificationManager.IMPORTANCE_LOW);
    t.setDescription("시간 측정 중일 때 알림 창에 타이머를 보여 줘요");
    t.setShowBadge(false);
    nm.createNotificationChannel(t);
    NotificationChannel r = new NotificationChannel(CH_REMIND, "일정 · 미룬 할 일", NotificationManager.IMPORTANCE_HIGH);
    r.setDescription("수행평가 전날, 미룬 할 일이 쌓였을 때 알려 줘요");
    nm.createNotificationChannel(r);
  }

  static PendingIntent open(Context c, String go, int req) {
    Intent i = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
    if (go != null) i.putExtra("go", go);
    return PendingIntent.getActivity(c, req, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
  }

  static RemoteViews view(Context c, int layout, boolean running, long elapsed, String title) {
    RemoteViews v = new RemoteViews(c.getPackageName(), layout);
    v.setTextViewText(R.id.state, running ? "공부 중" : "일시정지");
    v.setTextViewText(R.id.title, title);
    v.setChronometer(R.id.chrono, SystemClock.elapsedRealtime() - elapsed, null, running);
    return v;
  }

  static void timer(Context c, boolean running, long elapsed, String title) {
    channels(c);
    Notification n = new Notification.Builder(c, CH_TIMER)
        .setSmallIcon(R.drawable.ic_stat)
        .setColor(Color.parseColor("#D2638A"))
        .setStyle(new Notification.DecoratedCustomViewStyle())
        .setCustomContentView(view(c, R.layout.notif_timer, running, elapsed, title))
        .setCustomBigContentView(view(c, R.layout.notif_timer_big, running, elapsed, title))
        .setContentTitle(running ? "공부 중" : "일시정지")
        .setContentText(title)
        .setCategory(android.os.Build.VERSION.SDK_INT >= 31 ? Notification.CATEGORY_STOPWATCH : Notification.CATEGORY_PROGRESS)
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .setShowWhen(false)
        .setContentIntent(open(c, null, 1))
        .build();
    c.getSystemService(NotificationManager.class).notify(ID_TIMER, n);
  }

  static void timerStop(Context c) { c.getSystemService(NotificationManager.class).cancel(ID_TIMER); }

  static void remind(Context c, int id, String title, String body, String go) {
    channels(c);
    Notification n = new Notification.Builder(c, CH_REMIND)
        .setSmallIcon(R.drawable.ic_bell)
        .setColor(Color.parseColor("#D2638A"))
        .setContentTitle(title)
        .setContentText(body.replace("\n", " · "))
        .setStyle(new Notification.BigTextStyle().bigText(body))
        .setAutoCancel(true)
        .setContentIntent(open(c, go, 10 + id))
        .build();
    c.getSystemService(NotificationManager.class).notify(id, n);
  }
}
